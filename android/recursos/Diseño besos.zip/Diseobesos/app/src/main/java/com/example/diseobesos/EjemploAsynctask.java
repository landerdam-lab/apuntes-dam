package com.example.diseobesos;

import android.content.res.TypedArray;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class EjemploAsynctask extends AppCompatActivity {

    private TypedArray imagenes = null;
    private ProgressBar barra = null;
    private ImageView imageCentral = null;
    private TextView texto = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_ejemplo_asynctask);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        imagenes = getResources().obtainTypedArray((R.array.imagenes));
        barra = findViewById(R.id.pbAnimacion);
        imageCentral = findViewById(R.id.ivAnimacion);
        texto = findViewById(R.id.tvAnimacion);

        barra.setMax(100);
        barra.setProgress(0);
        barra.setBackgroundColor(Color.GRAY);
        ProgressAndando hilo = new ProgressAndando(this);
        hilo.execute();

    }

    public void finalizar(){
        this.finish();
    }

    public TypedArray getImagenes(){
        return  this.imagenes;
    }

    public void setImagenes(TypedArray imagenes){
        this.imagenes = imagenes;
    }

    public ImageView getImageCentral() {
        return imageCentral;
    }

    public void setImageCentral(ImageView imageCentral) {
        this.imageCentral = imageCentral;
    }

    public TextView getTexto() {
        return texto;
    }

    public void setTexto(TextView texto) {
        this.texto = texto;
    }

    public ProgressBar getBarra() {
        return barra;
    }

    public void setBarra(ProgressBar barra) {
        this.barra = barra;
    }
}